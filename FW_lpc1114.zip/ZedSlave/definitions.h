#ifndef DEFINITIONS
#define DEFINITIONS

// RUNTIME DEFINITIONS
    // MOTOR AND WHEELS         
    #define MOTORS_NUM          2
    #define MOTOR_TYPE          37
    #define WHEEL_DIAMETER      165     //  mm

    // CONTROLERS SETTINGS
    #define REG_FREQ            20.0    // [HZ]
    
// INTERNAL MACROS
    #define PI                  3.1415926
    
    //MOTORS
    #if MOTOR_TYPE == 25
        #define GEAR_RATIO      72
        #define RPM             130
        #define CPR             48
    #elif MOTOR_TYPE == 37
        #define GEAR_RATIO      50
        #define RPM             200
        #define CPR             64
    #endif
    
    #define MAX_TICKS_PER_UPDATE    RPM/60.0/REG_FREQ*CPR*GEAR_RATIO*0.7
    #define MAX_MOTOR_POWER         100

#endif