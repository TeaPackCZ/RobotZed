#include "mbed.h"
#include "definitions.h"
#include "Encoder.h"
#include "MotorDriver.h"

SPISlave spiin(dp2,dp1,dp6,dp25);

/*
Driver A:

PWM:    dp18
InA:    dp13
InB:    dp17
Sense:  dp11        

Encoder A:
Ch1:    dp28
Ch2:    dp27

Driver B:
PWM:    dp24
InA:    dp26
InB:    dp9
Sense:  dp4

Encoder B:
Ch1:    dp15
Ch2:    dp16
*/

MotorDriver MotA(dp18,dp13,dp17);
AnalogIn senseA(dp11);

MotorDriver MotB(dp24,dp26,dp9);
AnalogIn senseB(dp4);

Encoder enc_MA(dp28,dp27);
Encoder enc_MB(dp16,dp15);

DigitalOut StatusLed(dp10);
DigitalOut ErrLed(dp14);

Ticker controllerTicker;

Ticker  watchDog;
Timer   timeoutTimer;
bool    timeout;
int     i;

uint16_t encode_data(int enc1, int enc2, float cur1, float cur2)
{
    uint16_t output = (int(cur2*10) << 26) + ((int(cur1*10)&0x3F) << 20) + ((enc2 & 0x3FF) << 10 ) + (enc1 & 0x3FF);
    return output;
}

uint16_t get_state()
{
    uint16_t reply = (enc_MB.isEnabled() << 5) + (enc_MA.isEnabled() << 4) + (MotB.isEnabled() << 3 ) + (MotA.isEnabled() << 2) + 0x5500;
    return reply;
}

void control()
{
    enc_MA.getDist();
    enc_MB.getDist();
    i++;
    if((i%100 == 0) && !timeout)
        StatusLed = !StatusLed;
}

void WatchDog()
{
    if(timeoutTimer.read_ms() > 1000)
    {
        timeout = true;
        MotA.setEnabled(false);
        MotB.setEnabled(false);
        StatusLed = 0;
        ErrLed = !ErrLed;
    }
    else
    {
        if(timeout)
        {
            timeout = false;
            StatusLed = 1;
            ErrLed = 0;
        }
    }
}

int main() {
    
    controllerTicker.attach_us(control, 5000);
    
    timeoutTimer.start();
    watchDog.attach(WatchDog,0.2);
    
    ErrLed = 1;
    StatusLed = 0;
    
    uint16_t cmd, Reply;
    
    spiin.format(16,1);
    //spiin.frequency(1000000);     //Default is 1MHz
    spiin.reply(0xF0F0);
    
    enc_MA.setEnabled(true);
    enc_MB.setEnabled(true);
    MotA.setEnabled(true);
    MotB.setEnabled(true);
    
    ErrLed = 0;
    StatusLed = 1;
    
    while(1)
    {
        if(spiin.receive()) 
        {
            cmd = spiin.read();
            timeoutTimer.reset();
            switch(cmd)
            {
            case 0xFF00:                // Enable Motors
                MotA.setEnabled(true);
                MotB.setEnabled(true);
                spiin.reply(0x0000);
                break;
            case 0xFFAA:                // Disable motors
                MotA.setEnabled(false);
                MotB.setEnabled(false);
                spiin.reply(0x0000);
                break;
            case 0xFF0F:                // heart beat for Master Mbed
                spiin.reply(0x00F0);
                break;
            case 0xFFFE:                // Empty cmd
                spiin.reply(0x0000);    
                break;
            case 0xFFFA:                // Distance of motor A
                Reply = enc_MA.getTotalDist();
                spiin.reply(Reply);
                break;
            case 0xFFFB:                // Distance of motor B
                Reply = enc_MB.getTotalDist();
                spiin.reply(Reply);
                break;
            case 0xFFCA:                // Current thru motor A
                Reply = senseA.read_u16();
                spiin.reply(Reply);
                break;
            case 0xFFCB:                // Current thru motor B
                Reply = senseB.read_u16();
                spiin.reply(Reply);
                break;
            case 0xFFFD:                // Self test command
                spiin.reply(0xF0F0);
                // checkOutput();
                break;
            default:                    // Setting speed of motors
                uint8_t spdB = (cmd >> 8) & 0x7f;
                bool drB  = (cmd >> 15);
                
                uint8_t spdA = (cmd & 0x7F);
                bool drA  = (cmd & 0x80) >> 7;
                
                if((spdA < 101) && (spdB < 101))    // Correct speed size check
                {
                    //controller.set_speed_setpoints(drA,spdA,drB,spdB);
                    MotA.setSpeed(drA, spdA);
                    MotB.setSpeed(drB, spdB);
                }
                spiin.reply(get_state());
            }
        }
    }
}