#include "SlaveAxis.h"

SlaveAxis::SlaveAxis(PinName Mosi, PinName Miso, PinName Sck, PinName CS0, PinName CS1, PinName CS2, PinName Reset):
        _spi(Mosi, Miso, Sck), _SSels(CS0, CS1, CS2), _reset(Reset, PullUp)
{
    _SSels = 0x7;
    _spi.format(16,1);
    //spi.frequency(1000000);   // Default 1MHz
    _reset = 0;
    enabled = false;
    inreset = true;
    
    questions[0] = 0xFFFA;
    questions[1] = 0xFFFB; 
    questions[2] = 0xFFCA;
    questions[3] = 0xFFCB; 
    questions[4] = 0xFF0F;
    
    //            axes / index
    wheel_coeficient[0] = -1;
    wheel_coeficient[1] = 1;
    
    axis_coeficient[0] = 1;
    axis_coeficient[1] = 1;
    
    
    for(int i = 0; i< AXES_NUM; i++)
    for(int j = 0; j< MOTORS_NUM; j++)
    {
        old_position[i][j] = 0;
        position[i][j] = 0;
        new_diff[i][j] = 0;
    }
}

void SlaveAxis::start()
{
    _reset = 1;
}

void SlaveAxis::reset()
{
    inreset = 1;
    _reset = 0;
    wait(0.1);
    _reset = 1;
    wait(0.1);
    inreset = 0;
}

void SlaveAxis::setEnabled(bool state)
{
    enabled = state;
    if(enabled && !_reset)
        _reset = 1;
    
    if(enabled)
    {
        for(int i=0; i<AXES_NUM; i++)
        {
            _SSels[i] = 0;
            _spi.write(ENABLE);
            _SSels[i] = 1;
        }
    }
    else
    {
        for(int i=0; i<AXES_NUM; i++)
        {
            _SSels[i] = 0;
            _spi.write(DISABLE);
            _SSels[i] = 1;
        }
    }
}

bool SlaveAxis::isEnabled()
{
    return enabled;
}

void SlaveAxis::setSpeeds(int speeds[][MOTORS_NUM])
{
    int spd[2];
    for(int i=0; i<AXES_NUM; i++)
    {
        spd[0] = speeds[i][0]*wheel_coeficient[0]*axis_coeficient[i];
        spd[1] = speeds[i][1]*wheel_coeficient[1]*axis_coeficient[i];
        
        write( i, spd);
    }
}

void SlaveAxis::setSpeeds(float speeds[][MOTORS_NUM])
{
    int spd[2];
    for(int i=0; i<AXES_NUM; i++)
    {
        spd[0] = (int)speeds[i][0]*wheel_coeficient[0]*axis_coeficient[i];
        spd[1] = (int)speeds[i][1]*wheel_coeficient[1]*axis_coeficient[i];
        
        write( i, spd);
    }
}

void SlaveAxis::write(int cs, int speed[2])
{
    if(enabled)
    {   
        bool dir[2];
        uint8_t spd[2];
        
        for(int i=0; i<2; i++)
        {
            if(speed[i] <-100)
                speed[i] = -100;
            else if(speed[i] > 100)
                speed[i] = 100;
            
            if(speed[i] < 0)
                dir[i] = 1;
            else
                dir[i] = 0;
            
            spd[i] = abs(speed[i]);
        }
        
        uint16_t toWrite = (dir[0]<<15) + (spd[0]<<8) + (dir[1]<<7) + spd[1];
        
        _SSels[cs] = 0;
        returns[cs] = _spi.write(toWrite);
        _SSels[cs] = 1;
    }
}

void SlaveAxis::checkState(int cs)
{   
    _SSels[cs] = 0;
    returns[cs] = _spi.write(0xFFFE);
    _SSels[cs] = 1;
    
    bool motA_state = ((returns[cs] >> 2)&0x1);
    bool motB_state = ((returns[cs] >> 3)&0x1);
    is_connected[cs] = false;
    is_connected[cs] = ((returns[cs] & 0xFF00) == 0x5500);
    
    if( !(motA_state && motB_state) && enabled)
    {
        wait(WAIT_TIME);
        _SSels[cs] = 0;
        _spi.write(ENABLE);
        _SSels[cs] = 1;
    }
    wait(WAIT_TIME);
}

void SlaveAxis::getInfo(uint16_t pos[][INFO_LEN])
{   
    
//    uint16_t questions[INFO_LEN+1] = {0xFFFA, 0xFFFB, 0xFFCA, 0xFFCB, 0xFF0F};
    
    for(int q=0; q<INFO_LEN+1; q++)
        for(int i=0; i<AXES_NUM; i++)
        {
            if(q==0)
            {
                _SSels[i] = 0;
                _spi.write(questions[q]);
                _SSels[i] = 1;
                wait(WAIT_TIME/AXES_NUM);
            }
            else
            {
                _SSels[i] = 0;
                pos[i][q-1] = _spi.write(questions[q]);
                _SSels[i] = 1;
                wait(WAIT_TIME/AXES_NUM);
            }
        }
    
    for(int i=0; i<AXES_NUM; i++)
        for(int j=0; j<MOTORS_NUM; j++)
            addPosition(i,j,pos[i][j]);

}

int32_t SlaveAxis::getPosition(int axis, int wheel)
{
    return position[axis][wheel]*axis_coeficient[axis];
}

void SlaveAxis::addPosition(int a, int m, uint16_t new_data)
{
    new_diff[a][m] = int32_t(uint32_t(new_data)) - int32_t(uint32_t(old_position[a][m]));
    
    if( abs(new_diff[a][m] ) > 32767)
    {
        if( new_diff[a][m] > 0)
        {
            new_diff[a][m] =  (new_diff[a][m] - 0x0000FFFF);
        }
        else
        {
            new_diff[a][m] =  (new_diff[a][m] + 0x0000FFFF);
        }
    }

    position[a][m] +=  new_diff[a][m];
    
    corrected_diff[a][m] = new_diff[a][m]*axis_coeficient[a];
    
    old_position[a][m] = new_data;
}

float SlaveAxis::get_avg_speed()
{
    float avg_spd = 0;
    for(int i=0; i<AXES_NUM; i++)
        for(int j=0; j<MOTORS_NUM; j++)
            avg_spd += ( abs(new_diff[i][j]) / 1000.0 / TICK_P_MM * REG_FREQ );
    return avg_spd/(AXES_NUM*MOTORS_NUM);
}