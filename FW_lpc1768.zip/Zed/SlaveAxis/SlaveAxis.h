#include "mbed.h"
#include "definitions.h"

#ifndef SLAXIS
#define SLAXIS

#define GET_POS_A   0xFFFA
#define GET_POS_B   0xFFFB
#define GET_CUR_A   0xFFCA
#define GET_CUR_B   0xFFCB

#define ENABLE      0xFF00
#define DISABLE     0xFFAA

#define WAIT_TIME   0.00015
#define INFO_LEN    4


class SlaveAxis{

public:
    SlaveAxis(PinName Mosi, PinName Miso, PinName Sck, PinName CS0, PinName CS1, PinName CS2, PinName Reset);
    
    void start();
    
    void reset();
    
    void setEnabled(bool);
    
    bool isEnabled();
    bool isConnected();
    
    void setSpeeds(int[][MOTORS_NUM]);
    void setSpeeds(float[][MOTORS_NUM]);
    
    void getInfo(uint16_t pos[][INFO_LEN]);
    
    int32_t getPosition(int, int);
    
    void addPosition(int axis, int motor, uint16_t new_data);
    
    float get_avg_speed();
    
    int32_t corrected_diff[AXES_NUM][MOTORS_NUM];
    
private:
    SPI _spi;
    BusOut _SSels;
    DigitalOut _reset;
    
    void checkState(int);
    void check_connection(uint16_t);
    void write(int, int[]);
    
    bool enabled;
    bool inreset;
    
    uint16_t questions[INFO_LEN+1];
    
    uint16_t old_position[AXES_NUM][MOTORS_NUM];
    uint16_t returns[AXES_NUM];
    
    bool is_connected[AXES_NUM];
    int32_t position[AXES_NUM][MOTORS_NUM];
    int32_t new_diff[AXES_NUM][MOTORS_NUM];
    
    int wheel_coeficient[MOTORS_NUM];
    int axis_coeficient[AXES_NUM];
    
};

#endif