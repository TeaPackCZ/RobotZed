#ifndef MySerial_h 
#define MySerial_h

#include "mbed.h"
#include "definitions.h"

class MySerial{

public:
    
    MySerial(PinName rx, PinName tx, PinName led, int baudrate);

    int refresh();
    void send(char,int, int, int, int);
    void send(char[],char,int);
    void sprint(char[]);
    
    char get_style();
    
    int speed[6];           // array of speeds
    int tachoL, tachoR;     // number of pulses, after which robot stops movement
    
    int request, status, setpoint;
    // chenged from private for debug purposes
    int radius, power;
    float alfa;
    
private:

    Serial _mys;
    DigitalOut _led;
    char msg[250];
    void getline();
    
    // characteristics of actual movement
    char style, device;
    
    int tpcm;       // Ticks from encoder per one centimeter
    float dkx;      // width of platform
    int dky;        // wheel base
    float O[6];     // length of arcs
    float r[6];     // radiuses for each wheel
    float R;        // radius in cm or distance in cm
    
    int round(float);
  
};

#endif