#include "MySerial.h"
#include "math.h"
#include "definitions.h"

MySerial::MySerial(PinName tx, PinName rx, PinName led, int baudrate) : _mys(tx, rx), _led(led) {
        _mys.baud(baudrate);
        dky=13;
        dkx=15.5;
        tpcm=100918/1269.5;
}

int MySerial::refresh(){
    while(1)
    {
        getline();
        
        // scanning for SetMove msg
        if(sscanf(msg,"setM,%c,%d,%f,%d", &style, &radius, &alfa, &power)>=3)
        {
            switch(style)
            {
            case 'K':       // drive with Kinect
                //_mys.printf("$Move - Kinect\r\n");
                return SET_K_MOVE;
            case 'D':
                return SET_D_MOVE;
            default:
                _mys.printf("$,&,Bad move format!\r\n");
                return -1;
            }
        }
        else if(sscanf(msg,"setD,%c,%d,%d", &device, &status, &setpoint)>=2)
        { switch (device)
            {
            case 'U':       // Setting US senzors
                return SET_US;
            case 'G':
                return SET_GPS;
            case 'I':
                return SET_IMU;
            case 'T':
                return TERMINATE;
            case 'M':
                return SET_MOTORS;
            case 'C':
                return SET_CONTROLER;
            case 'B':
                return 0xBB;
            default:        // failuire case
                _mys.printf("$,&,Bad SET format!\r\n");
                return -1;
            }
        }
        else if(sscanf(msg,"get,%d", &request)>0)
        { 
            return request;
        }
        else
        {
            _mys.printf("$,&,Bad, bad format received!\r\n");
        }
    }
}


void MySerial::getline()
{
    while(_mys.getc()!='$');
    for(int i=0; i<250; i++)
    {
        msg[i]=_mys.getc();
        _led=!_led;
        if (msg[i]=='\r')
        {   msg[i]=0;
            return;
        }
    }
}

void MySerial::send(char str,int int1, int int2, int int3, int int4)
{
    _mys.printf("$,%c,%d,%d,%d,%d\r\n",str,int1, int2, int3, int4);
}

void MySerial::send(char bfr[], char str,int int1)
{
    _mys.printf("$%s,%c,%d,\r\n",bfr,str,int1);
}

void MySerial::sprint(char bfr[])
{
    _mys.printf("$,%s\r\n",bfr);
}

char MySerial::get_style()
{   return style;   }

int MySerial::round(float a){
    return (int(a)+((int)(a*2)%2));
}