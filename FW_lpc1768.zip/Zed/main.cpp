#include "mbed.h"
#include <math.h>
#include "SlaveAxis.h"
#include "definitions.h"
#include "MySerial.h"

DigitalOut led0(LED1);
DigitalOut led1(LED2);
DigitalOut led2(LED3);
DigitalOut led3(LED4);

SlaveAxis axes(p5,p6,p7,p15,p10,p9,p8);

/** TO be moved to USB Data +/- or p28,p27 */
MySerial MASTER(p13,p14,LED4,115200);
//MySerial MASTER(USBTX,USBRX,LED4,115200);

/** Battery 1 (2s/3s)
 *      Connected to pin 20 with resistor divider (6.8k/3.3k)
 *      Connected is only GND and second cell of battery (2S = full voltage, 3S = 2/3 voltage)
 *
 *   TO BE MOVED TO MULTIPLEXOR, TO CHECK ALL CELLS OF ALL BATTERIES
 *
 */
AnalogIn bat1(p20);

PwmOut speaker(p21);

Ticker BatteryKeeper;
Ticker ControllerKeeper;
Ticker dummyTicker;

bool spkr_enabled;
bool enabled;
bool bat1Empty;
char buff[255];

void toggleBeeper(void)
{
    spkr_enabled = !spkr_enabled;
    if(spkr_enabled)
        speaker.write(0.5);
    else
        speaker.write(0);
}

void check_batteries()
{
    float Bat1;
    
    Bat1 = bat1.read()*18.525;
    
    Bat1 *= (Bat1>1)? 1 : 0;
    
    if(Bat1 < 1)
    {
        MASTER.sprint("&ERR: BAT1 NOT CONNECTED!!");
        speaker.write(0.5);
    }
    else if(Bat1 < 3*BAT_CELL_MIN)
    {
        bat1Empty = true;
        MASTER.sprint("&ERR: BAT1 is empty!!");
        toggleBeeper();
    }
    else if(Bat1 < 3*BAT_CELL_LOW)
        MASTER.sprint("&WRN: BAT1 is low!!");
        
    sprintf(buff, "&MSG: BATTERY 3S: %.2fV", Bat1);
    MASTER.sprint(buff);
}

/** END of controls */
int wheel_position[AXES_NUM][MOTORS_NUM];
uint16_t info[AXES_NUM][INFO_LEN];
float tickSetpoints[AXES_NUM][MOTORS_NUM];
float integral[AXES_NUM][MOTORS_NUM];
float regSpeeds[AXES_NUM][MOTORS_NUM];
int oldDistance;
float masterSpeedSetpoint;
float speedSetpoint;
float direction_angle;
float speed_diff;
bool DRIVE_ENABLED;

bool positionEnabled;

void regulate(float speeds[][MOTORS_NUM], int diff[][MOTORS_NUM])
{
    for(int i = 0; i<AXES_NUM; i++)
        for(int j = 0; j<MOTORS_NUM; j++)
        {
            float e = tickSetpoints[i][j] - diff[i][j];
            speeds[i][j] += KP*e;
            
            if(speeds[i][j] > MAX_MOTOR_POWER)
            {
                speeds[i][j] = MAX_MOTOR_POWER;
            }
            if(speeds[i][j] < -MAX_MOTOR_POWER)
            {
                speeds[i][j] = -MAX_MOTOR_POWER;
            }
        }
}

void set_speedSetpoints(float internal_speedSetpoint, float angle)
{
    if(angle < 0.8)
        angle = 0.8;
    else if( angle > 1.2)
        angle = 1.2;
  
    // speed * TpMM ( m/s * 1000) * (tick/mm) / regFreq = (tick/s)/Hz -> ticks per period
    tickSetpoints[0][wheel_position[0][0]] = internal_speedSetpoint * 1000.0 * TICK_P_MM / REG_FREQ * (2-angle);
    tickSetpoints[0][wheel_position[0][1]] = internal_speedSetpoint * 1000.0 * TICK_P_MM / REG_FREQ * angle;
    tickSetpoints[1][wheel_position[1][0]] = internal_speedSetpoint * 1000.0 * TICK_P_MM / REG_FREQ * (2-angle);
    tickSetpoints[1][wheel_position[1][1]] = internal_speedSetpoint * 1000.0 * TICK_P_MM / REG_FREQ * angle;
    
    speedSetpoint = internal_speedSetpoint;
}

void set_diff_speeds(float speed_left, float speed_right)
{
    if(speed_left > 1)
        speed_left = 1;
    else if(speed_left < -1)
        speed_left = -1;
    
    if(speed_right > 1)
        speed_right = 1;
    else if(speed_right < -1)
        speed_right = -1;
    
    tickSetpoints[0][wheel_position[0][0]] = MAX_SPEED * 1000.0 * TICK_P_MM / REG_FREQ * speed_left;
    tickSetpoints[0][wheel_position[0][1]] = MAX_SPEED * 1000.0 * TICK_P_MM / REG_FREQ * speed_right;
    tickSetpoints[1][wheel_position[1][0]] = MAX_SPEED * 1000.0 * TICK_P_MM / REG_FREQ * speed_left;
    tickSetpoints[1][wheel_position[1][1]] = MAX_SPEED * 1000.0 * TICK_P_MM / REG_FREQ * speed_right;
}

void speed_control(int distance, float angle, int &elapsedTime, float current_speed)
{
    direction_angle = angle;
    
    if(oldDistance == 0)
        {
            masterSpeedSetpoint = 0.0;
            oldDistance = distance;
        }
        
        //float speed_diff = float(oldDistance - distance)/(elapsedTime/10.0);     // m/s = (cm/100)/(ms/1000) = cm/(ms/10)
        speed_diff = float(oldDistance - distance)/(elapsedTime/10.0);
        
        oldDistance = distance;
        
        if(distance < OPTIMAL_DISTANCE)
        {
            if(speed_diff < 0)
                masterSpeedSetpoint = current_speed + 0.2;
            else
                masterSpeedSetpoint = current_speed + 0.2 + speed_diff;
        }
        else if(distance > MAXIMAL_DISTANCE)
        {
            if(speed_diff > 0)
                masterSpeedSetpoint = current_speed - 0.2;
            else
                masterSpeedSetpoint = current_speed - 0.2 + speed_diff;
        }
        else
            masterSpeedSetpoint = current_speed + speed_diff;
        
        if(masterSpeedSetpoint > MAX_SPEED)
            masterSpeedSetpoint = MAX_SPEED;
        else if(masterSpeedSetpoint < MIN_SPEED)
            masterSpeedSetpoint = MIN_SPEED;
}

void ramp_speed_setpoints()
{
    if(abs(masterSpeedSetpoint - speedSetpoint) > (MAX_SPEED_STEP*2))
    {
        if(masterSpeedSetpoint >= 0)
        {
            if(speedSetpoint > masterSpeedSetpoint)
                speedSetpoint -= MAX_SPEED_STEP;
            else if(speedSetpoint < masterSpeedSetpoint)
                speedSetpoint += MAX_SPEED_STEP;
        }
        else
        {
            if(speedSetpoint > masterSpeedSetpoint)
                speedSetpoint += MAX_SPEED_STEP;
            else if(speedSetpoint < masterSpeedSetpoint)
                speedSetpoint -= MAX_SPEED_STEP;
        }
    }
    else
        speedSetpoint = masterSpeedSetpoint;
        
    set_speedSetpoints(speedSetpoint,direction_angle);
}

void control_loop(void)
{
    axes.getInfo(info);
    
    //ramp_speed_setpoints();
    
    regulate(regSpeeds, axes.corrected_diff);
    
#if TACHOLIMIT != 0
    for(int i = 0; i<AXES_NUM; i++)
        for(int j = 0; j<MOTORS_NUM; j++)
            if((abs(axes.getPosition(i,j)) > TACHOLIMIT_TICKS))
            {
                DRIVE_ENABLED = false;
                axes.setEnabled(false);
            }
#endif
    axes.setSpeeds(regSpeeds);
    
    if(positionEnabled)
    {
        sprintf(buff,"&POS,%d,%d,%d,%d", axes.getPosition(0,0), axes.getPosition(0,1)
                , axes.getPosition(1,0), axes.getPosition(1,1));
        MASTER.sprint(buff);
        sprintf(buff,"&CUR,%d,%d,%d,%d", info[0][2], info[0][3], info[1][2], info[1][3]);
        MASTER.sprint(buff);
    }

#if DEBUG_SPI == 1
    sprintf(buff,"&DBG: Axis 0: %d\t%d\t%d\t%d\t%d\t%d", info[0][0], info[0][1]
        , axes.corrected_diff[0][0], axes.corrected_diff[0][1], axes.getPosition(0,0), axes.getPosition(0,1));
    MASTER.sprint(buff);
    sprintf(buff,"&DBG: Axis 1: %d\t%d\t%d\t%d\t%d\t%d", info[1][0], info[1][1]
        , axes.corrected_diff[1][0], axes.corrected_diff[1][1], axes.getPosition(1,0), axes.getPosition(1,1));
    MASTER.sprint(buff);
#endif

}

int dummyIndex;
void dummyRun(void)
{
        
    axes.setEnabled(true);
    set_diff_speeds(0.8, 0.8);
    
    led3 = !led3;
    
#if DEBUG_SPI == 1
    sprintf(buff,"&DBG: Axis 0: %d\t%d\t%d\t%d\t%d\t%d", info[0][0], info[0][1]
        , axes.corrected_diff[0][0], axes.corrected_diff[0][1], axes.getPosition(0,0), axes.getPosition(0,1));
    MASTER.sprint(buff);
    sprintf(buff,"&DBG: Axis 1: %d\t%d\t%d\t%d\t%d\t%d", info[1][0], info[1][1]
        , axes.corrected_diff[1][0], axes.corrected_diff[1][1], axes.getPosition(1,0), axes.getPosition(1,1));
    MASTER.sprint(buff);
#endif
}

void init_controller()
{
    for(int i=0; i<AXES_NUM; i++)
        for(int j=0; j<MOTORS_NUM; j++)
        {
            integral[i][j] = 0;
            regSpeeds[i][j] = 0;
            tickSetpoints[i][j] = 0;
        }
    masterSpeedSetpoint = 0.0;
    speedSetpoint = 0;
}

int main() {
    
/** Startup LVL1
 *      Terminal setup. setting default values
 */
    speaker.period(0.002);
    speaker.write(0.5);
    wait(0.5);
    speaker.write(0);
    spkr_enabled = false;
 
    wheel_position[0][0] = WHEEL_RIGHT;
    wheel_position[0][1] = WHEEL_LEFT;
    wheel_position[1][0] = WHEEL_RIGHT;
    wheel_position[1][1] = WHEEL_LEFT;
 
    enabled = true;
    bat1Empty = false;
    positionEnabled = false;
    DRIVE_ENABLED = false;
    
    init_controller();
    
    led0 = 1;
    led1 = 1;
    led2 = 1;
    led3 = 1;

/** Startup LVL 2
 *      Connecting voids to interrupts and timers
 *      reseting slave controllers to default
 */

    BatteryKeeper.attach(check_batteries,1.002);
    
    axes.reset();
    axes.setEnabled(false);
    
    wait(0.5);
    
#if DUMMYRUN==0
    ControllerKeeper.attach_us(control_loop, (int)(1000000/REG_FREQ));
#else
    dummyIndex = 0;
    dummyTicker.attach(dummyRun, 1);
#endif

    led0 = 0;
    led1 = 0;
    led2 = 0;
    led3 = 0;

/** Startup LVL3
 *     Checking default state of peripherials
 *     Creating localy used variables, mainly for debug etc...
 */ 
    
    wait(0.5);
    
    MASTER.sprint("&DBG: START");
    
    int arg;
    
/** Start of loop
 *
 */
    while(enabled)
    {
        arg = MASTER.refresh();
        if(!enabled)
            break;
        
        switch(arg)
        {
        case SET_MOVE:
            break;
        case SET_D_MOVE:
            //KinectTimer.reset();
            //set_speedSetpoints(MASTER.radius/100.0, MASTER.alfa);
            if(DRIVE_ENABLED)
            {
                set_diff_speeds(MASTER.radius/100.0, MASTER.alfa/100.0);
#if DEBUG_SERIAL == 1
                sprintf(buff,"&Running %f, %f, (0-1),(0-1)", MASTER.radius/100.0, MASTER.alfa/100.0);
                MASTER.sprint(buff);
#endif
            }
            else
            {
#if DEBUG_SERIAL == 1
                MASTER.sprint("&,Move is not enabled...\r\n");
#endif
            }
            break;
        case SET_MOTORS:
            if(MASTER.setpoint)
            {
                DRIVE_ENABLED = true;
                positionEnabled = true;
                axes.setEnabled(true);
#if DEBUG_SERIAL == 1
                printf(buff,"&,Motors enabled");
                MASTER.sprint(buff);
#endif
            }
            else
            {
                DRIVE_ENABLED = false;
                axes.setEnabled(false);
                positionEnabled = false;
#if DEBUG_SERIAL == 1
                MASTER.sprint("&,Motors off");
#endif
            }
            break;
        case SET_CONTROLER:
            if(MASTER.setpoint)
            {
                axes.setEnabled(false);
                axes.reset();
                init_controller();
                axes.setEnabled(true);
#if DEBUG_SERIAL == 1
                printf(buff,"&,Controller restarted");
                MASTER.sprint(buff);
#endif
            }
            break;
        case GET_POSITION: //get,42,
            sprintf(buff,"%d,%d,%d,%d", axes.getPosition(0,0), axes.getPosition(0,1)
                , axes.getPosition(1,0), axes.getPosition(1,1));
            MASTER.sprint(buff);
            break;
        case CLR_POSITION:// get,43,
            axes.reset();
            break;
        case 0xBB:
            printf(buff,"&,Beeping... ... ...");
            MASTER.sprint(buff);
            spkr_enabled = true;
            speaker.write(0.5);
            wait(0.5);
            speaker.write(0);
            wait(0.5);
            speaker.write(0.5);
            wait(0.5);
            speaker.write(0);
            spkr_enabled = false;
            break;
        case TERMINATE:
            enabled = false;
            positionEnabled = false;
            break;
        default:
            ;
        }
    }
#if DEBUG_SERIAL == 1
    MASTER.sprint("&DBG: Terminating program ... \r\n");
    MASTER.sprint("&DBG: HALT");
#endif
    ControllerKeeper.detach();
    BatteryKeeper.detach();
    axes.setEnabled(false);
}