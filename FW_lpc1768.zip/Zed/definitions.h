#ifndef DEFINITIONS
#define DEFINITIONS

#define DUMMYRUN        0

#define DEBUG_SPI       0
#define DEBUG_SERIAL    1
#define DEBUG_BUTTONS   1

// RUNTIME DEFINITIONS
    
    #define TICK_P_MM           7.1592f
    #define MAX_SPEED           0.6f         //m/s
    #define MIN_SPEED           0.0f
    #define TACHOLIMIT          350          //m

    //AXES, MOTORS AND WHEELS
    #define AXES_NUM            2
    #define MOTORS_NUM          2
    #define MOTOR_TYPE          37
    #define WHEEL_DIAMETER      165     //  mm

    // CONTROLERS SETTINGS
    #define REG_FREQ            40.0f    // Hz
    #define OPTIMAL_DISTANCE    300     // cm
    #define MAXIMAL_DISTANCE    450     // cm
    
// INTERNAL MACROS
    #define DEBUG               DEBUG_SPI || DEBUG_SERIAL || DEBUG_BUTTONS
    #define PI                  3.1415926f
    #define TACHOLIMIT_TICKS    TACHOLIMIT*1000*TICK_P_MM
    
    //MOTORS
    #if MOTOR_TYPE == 25
        #define GEAR_RATIO      72
        #define RPM             130
        #define CPR             48
    #elif MOTOR_TYPE == 37
        #define GEAR_RATIO      50
        #define RPM             200
        #define CPR             64
    #endif
    
    #define MAX_TICKS_PER_UPDATE    RPM/60.0/REG_FREQ*CPR*GEAR_RATIO
    #define MAX_MOTOR_POWER         100.0f
    
    //WHEELS
    #define WHEEL_RIGHT 1
    #define WHEEL_LEFT  0
    
    // INTERNAL CONTROLLER
    #define KP                  MAX_MOTOR_POWER/MAX_TICKS_PER_UPDATE/15.0f
    #define MAX_SPEED_STEP      (MAX_SPEED*1.0)/(REG_FREQ*1.0)/2.0f

    // BATTERIES
    #define BAT_CELL_MIN    3.3f
    #define BAT_CELL_LOW    3.4f
    
    // SERIAL MESSAGES
    #define SET_MOVE            0x01
    #define SET_D_MOVE          0x02
    #define SET_US              0x03
    #define SET_GPS             0x04
    #define SET_IMU             0x05
    #define SET_MOTORS          0x06
    #define SET_CONTROLER       0x07
    #define SET_K_MOVE          0x10
    
    #define GET_POSITION        0x2A
    #define CLR_POSITION        0x2B
    
    #define TERMINATE           0x39
    
#endif